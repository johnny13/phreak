<?php

/**
 * IconPhreaks | anything to do with icons
 * Date: July 16 2021
 */

namespace App\Commands\Phreaks;

use App\Commands\Phreaks\FilePhreaks;

// use Symfony\Component\Console\Helper\TableSeparator;
// use Phim\Color;
// use Roundcolor\PKRoundColor;
use League\CLImate\CLImate;


use SVG\SVG;

require_once "./libraries/svg/svglib/svglib.php";
require_once './libraries/svg/svglib/inkscape.php';

class IconPhreaks
{

    public static $NodeJS = "/home/lucky/.nvm/versions/node/v14.15.4/bin/node";

    /**
     * parse_json_list
     * Rename all files found in a JSON file of filenames
     *
     * @param string $file
     * @return bool
     */
    public static function parse_json_list($file)
    {
        $climate = new CLImate;

        $fileString = file_get_contents($file);
        $iconData = json_decode($fileString, true);
        $baseDir = dirname($file);

        $progress = $climate->progress()->total(100);

        if (is_array($iconData)) {
            $totalCats = count($iconData);
            $count = 1;

            foreach ($iconData as $categoryKey => $categoryDetails) {
                $prog = intval(($count / $totalCats) * 100);

                $iconTotal = count($categoryDetails["iconsArray"]);
                $climate->green()->out(" " . strtoupper($categoryKey) . " <blue>" . $iconTotal . "</blue>");

                FilePhreaks::batch_rename_files($categoryDetails["iconsArray"], $categoryKey, $baseDir);
                $count++;

                $progress->current($prog);
            }

            $climate->out(" ");
            return true;
        } else {
            $climate->out(" ");
            $climate->red()->bold()->out(" Invalid JSON File. Cannot continue!");
            $climate->out(" ");
            return false;
        }
    }

    /**
     * convert_to_svg
     * Takes a folder of EPS icon files and converts them to SVG Icons
     *
     * @param string $path
     * @param string $newDir
     * @return bool
     */
    public static function convert_to_svg($path, $newDir)
    {
        $climate = new CLImate;

        $ext = "eps";
        $count = 0;

        $findString = $path . DIRECTORY_SEPARATOR . "*." . $ext;

        $cleanFiles = glob($findString);
        $total = count($cleanFiles);

        $progress = $climate->progress()->total(100);

        FilePhreaks::dir_if_none($newDir);

        foreach ($cleanFiles as $file) {
            $count++;

            $prog = intval(($count / $total) * 100);

            $path_parts = pathinfo($file);

            $inkscape = new \Inkscape($file);

            $new_sized_SVG = $newDir . DIRECTORY_SEPARATOR . $path_parts["filename"] . ".svg";

            try {
                $ok = $inkscape->export('plain-svg', $new_sized_SVG);
            } catch (\Exception $exc) {
                $climate->red()->bold()->out(" [FAIL] " . $new_sized_SVG);
                $climate->red()->out($exc->getMessage());
                $climate->red()->out($exc->getTraceAsString());
            }

            $progress->current($prog);
        }

        $climate->green()->bold()->out(" [DONE] " . $total . " Files Processed!" . PHP_EOL);

        return true;
    }

    /**
     * resize_single
     *
     * @param string $icon
     * @param string $newName
     * @param int $wide
     * @param int $tall
     * @return bool
     */
    public static function resizeSingleSVG($icon, $newName, $wide = 500, $tall = 500)
    {
        $climate = new CLImate;

        $dom = new \DOMDocument('1.0', 'utf-8');
        $dom->load($icon);
        $svg = $dom->documentElement;

        if (!$svg->hasAttribute('viewBox')) {

            // viewBox is needed to establish
            // userspace coordinates
            $pattern = '/^(\d*\.\d+|\d+)(px)?$/'; // positive number, px unit optional

            $interpretable =  preg_match($pattern, $svg->getAttribute('width'), $width) &&
                preg_match($pattern, $svg->getAttribute('height'), $height);

            if ($interpretable) {
                $view_box = implode(' ', [0, 0, $width[0], $height[0]]);
                $svg->setAttribute('viewBox', $view_box);
            } else {
                // this gets sticky
                $climate->red()->bold()->out(" [FAIL] " . "viewBox is dependent on environment");

                return false;
            }
        }

        $svg->setAttribute('width', $wide);
        $svg->setAttribute('height', $tall);

        $dom->save($newName);

        return true;
    }

    /**
     * resize_icons
     *
     * @TODO add in support for PNG icons!
     *
     * @param string $path
     * @param string $newDir
     * @return void
     */
    public static function resize_icons($path, $newDir, $size = 500)
    {
        $climate = new CLImate;

        $wide = $size;
        $tall = $size;

        $findString = $path . "/*.svg";
        $files = glob($findString);

        $total = count($files);
        $climate->out(" ");
        $climate->cyan()->out("Processing " . $total . " files...");
        $climate->out(" ");

        $progress = $climate->progress()->total(100);

        $count = 0;

        FilePhreaks::dir_if_none($newDir);

        foreach ($files as $file) {
            $prog = intval(($count / $total) * 100);

            $path_parts = pathinfo($file);

            $n_file = $path_parts["filename"] . "." . $path_parts["extension"];
            $newSVG = $newDir . DIRECTORY_SEPARATOR . $n_file;

            self::resizeSingleSVG($file, $newSVG, $wide, $tall);

            $progress->current($prog);

            if ($count >= 9) {
                sleep(0.25);
            }
            $count = ($count > 10 ? 0 : ($count + 1));
        }

        $progress->current(100);
        return true;
    }

    /**
     * mono_replace
     *
     * @param string $ImageSvgFile
     * @param string $ImageColor
     * @return string XML DOMDocument
     */
    public static function mono_replace($ImageSvgFile, $ImageColor)
    {
        $FileContents = file_get_contents($ImageSvgFile);

        $doc = new \DOMDocument();

        $doc->preserveWhiteSpace = False;
        $doc->loadXML($FileContents) or die('Failed to load SVG file ' . $ImageSvgFile . ' as XML.  It probably contains malformed data.');

        $SvgTags = $doc->getElementsByTagName("svg");

        if (preg_match('/^([0-9a-f]{1,2}){3}$/i', $ImageColor) == false) {
            die('Invalid color: ' . $ImageColor);
        }

        //Replace XML Element Fill attribute w/ new color.
        $AllTags = $doc->getElementsByTagName("path");

        foreach ($AllTags as $ATag) {
            $VectorColor = $ATag->getAttribute('fill');
            $ATag->setAttribute('fill', '#' . $ImageColor);
            $FileContents = $doc->saveXML($doc);
        }

        return $FileContents;
    }

    public static function containsColor(string $input): bool
    {
        $pixelInfoList = [];
        exec(sprintf('convert "%s" -depth 8 -alpha Off --colors 255 -unique-colors txt:-', $input), $pixelInfoList);
        // ... Insert error handling here ...
        for ($index = 1; $index < count($pixelInfoList); $index++) {
            preg_match('/\((\d+),(\d+),(\d+)\)/', $pixelInfoList[$index], $colorParts);
            if ($colorParts[1] == $colorParts[2] && $colorParts[2] == $colorParts[3]) {
                // Color is gray. Do nothing?
            } else {
                // Non-gray color. Stop search, and return.
                return true;
            }
        }
        return false;
    }

    public static function find_all_colors($icon)
    {
        $climate = new CLImate;

        // TODO redo this to use PHP regrex searching stroke and fill inside SVG code.
        //$regex = "/#([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?\b/";

        $script = base_path("libraries/node_scripts/svg_colors.js");
        exec(self::$NodeJS . " " . $script . " " . $icon, $colors);

        var_dump($colors);

        exit;

        //
        // Run node_scripts/svg_colors.js on Target Directory or Target Icon?
        //
        // Next we replace all colors in icons with Palette Colors
        //

    }

    public static function palette_replace($ImageSvgFile, $PaletteColors)
    {
        //
        // @todo Finish his
        // @o
    }

    /**
     * batch_recolor_mono
     *
     * @param string $path
     * @param string $newColor
     * @param string $newDir
     * @return bool
     */
    public static function batch_recolor_mono($path, $newColor, $newDir = false)
    {

        // $input = file_get_contents($svgFile, FILE_USE_INCLUDE_PATH);
        // $output = preg_replace("/" . $pattern . "/", $replace, $input);

        $climate = new CLImate;

        $path = FilePhreaks::rem_tail($path);
        $findString = $path . "/**/*.svg";

        // If New Dir is set, we first do a recursive copy, then change the new icons colors.
        if ($newDir !== false) {
            $newDir = FilePhreaks::new_dir_overcheckconfirm($newDir, $path);
            $findString = $newDir . "/**/*.svg";
        }

        $climate->br()->cyan()->out(" Searching " . $findString . " ...");

        $files = glob($findString);
        $total = count($files);

        $climate->cyan()->out(" Processing " . $total . " files...")->br();
        $progress = $climate->progress()->total(100);

        $count = 0;
        foreach ($files as $file) {

            $progress->current(intval(($count / $total) * 100));

            $svgColored = self::mono_replace($file, $newColor);

            file_put_contents($file, $svgColored);

            $count++;
        }

        return true;
    }

    /**
     * batch_recolor_palette
     *
     * @param string $path
     * @param string $newColor
     * @param string $newDir
     * @return bool
     */
    public static function batch_recolor_palette($path, $paletteColors, $newDir = false)
    {

        $climate = new CLImate;

        $path = FilePhreaks::rem_tail($path);
        $findString = resource_path($path . "/*.svg");

        // If New Dir is set, we first do a recursive copy, then change the new icons colors.
        if ($newDir !== false) {
            $newDir = FilePhreaks::new_dir_overcheckconfirm($newDir, $path);
            $findString = resource_path($newDir . "/**/*.svg");
        }

        $climate->br()->cyan()->out(" Searching " . $findString . " ...");

        $files = glob($findString);
        $total = count($files);

        $climate->cyan()->out(" Processing " . $total . " files...")->br();
        $progress = $climate->progress()->total(100);

        $count = 0;

        foreach ($files as $file) {
            $progress->current(intval(($count / $total) * 100));

            $replaceColors = self::find_all_colors($file);
            $replaceColors = array();
            //self::palette_replace($file, $paletteColors, $replaceColors);

            $count++;
        }

        return true;
    }
}
