<?php

namespace App\Commands;

use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;

// PHREAK CLASSES
use App\Commands\Wallpaper\Actions;
use App\Commands\Phreaks\PalettePhreaks;
use App\Commands\Phreaks\TUI;

// MENU CLASSES
use PhpSchool\CliMenu\Builder\CliMenuBuilder;
use PhpSchool\CliMenu\CliMenu;
use PhpSchool\CliMenu\MenuItem\AsciiArtItem;
use PhpSchool\CliMenu\MenuStyle;
use PhpSchool\CliMenu\Input\Text;
use PhpSchool\CliMenu\Input\InputIO;

class IconCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'create and manage a collection of icons';

    public $fgPop    = 47;
    public $fgColor  = 84;
    public $bgColor  = 235;
    public $bgPop    = 232;
    public $width    = 130;
    protected $asciiArt = 'libraries/ascii/spaceman.txt';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $popupStyle = (new MenuStyle)
            ->setBg($this->bgPop)
            ->setFg($this->fgPop);

        $menuActions = array();

        $menuActions["temp"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };

        $menuActions["new_collection"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            // Clear Menu
            foreach ($menu->getItems() as $item) {
                $menu->removeItem($item);
            }

            $menu->redraw();

            // Pop up Dialog
            $result = $menu->askText($popupStyle)
                ->setPromptText('Name your new Palette')
                ->setPlaceholderText('.......?')
                ->setValidationFailedText('Invalid Name!')
                ->ask();

            var_dump($result->fetch());

            $this->mainMenuLoad();
        };


        $menuActions["view"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["info_dump"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["colorize"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["resize"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["convert"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["contact_sheet"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuActions["filter"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $filterSearch = $mainMenu->askText($popupStyle)
                ->setPromptText('Location to filter images from?')
                ->setPlaceholderText('.......?')
                ->setValidationFailedText('Invalid Path!')
                ->setValidator(function ($path) {
                    $path = (is_dir($path) ? $path : false);
                    return $path;
                })
                ->ask();

            $searchDirectory = $filterSearch->fetch();

            $filterSave = $mainMenu->askText($popupStyle)
                ->setPromptText('Where should we save the results?')
                ->setPlaceholderText('.......?')
                ->setValidationFailedText('Invalid Path!')
                ->setValidator(function ($path) {

                    if (!mkdir($path, 0777, true)) {
                        die('Failed to create Save Directory. Cannot Continue..');
                    }

                    $path = (is_dir($path) ? $path : false);
                    return $path;
                })
                ->ask();

            $saveDirectory = $filterSave->fetch();

            TUI::echoString("Searching:" . $searchDirectory . " Saving In:" . $saveDirectory);
            TUI::echoString("TODO: Implement this properly. Possibly use img-sort.sh script.");
        };


        $menuActions["web_export"] = function (\PhpSchool\CliMenu\CliMenu $mainMenu) {
            $item = $mainMenu->getSelectedItem()->getText();

            echo "TESTING: " . $item;

            PalettePhreaks::testingAccess($item);
        };


        $menuBuilder = new CliMenuBuilder();

        $this->buildMainMenu(
            $menuBuilder,
            $menuActions
        );

        $this->menu = $menuBuilder->build();
        $this->menu->open();
    }

    public function buildMainMenu(CliMenuBuilder $menuBuilder, $actions)
    {
        $art = file_get_contents(base_path($this->asciiArt));

        $menuBuilder
            ->addAsciiArt($art, AsciiArtItem::POSITION_CENTER, "  --  BLASTED  --")
            ->setTitleSeparator('■')
            ->setTitle('ICON MANAGER')
            ->setPadding(2, 4)
            ->setMarginAuto()
            ->setForegroundColour($this->fgColor)
            ->setBackgroundColour($this->bgColor)
            ->addLineBreak(' ')
            //->addStaticItem('PALETTE COMMANDS')
            ->addItem('Create New Collection', $actions["new_collection"], true)
            ->addItem('View Existing', $actions["view"])
            ->addItem('Icon Infodump', $actions["info_dump"])
            ->addItem('Colorize', $actions["colorize"])
            ->addItem('Resize Icons', $actions["resize"])
            ->addItem('SVG Conversion', $actions["convert"])
            ->addItem('Create Icon Contact Sheet', $actions["contact_sheet"])
            ->addItem('Filter Images', $actions["filter"], true)
            ->setItemExtra('[80%]')
            ->addItem('Web Export', $actions["web_export"])
            ->addLineBreak(' ')
            ->addStaticItem('BASE 16')
            ->addItem('Convert Palette to B16', $actions["temp"])
            ->addItem('Download Palettes', $actions["temp"])
            ->addItem('Download Templates', $actions["temp"])
            ->addItem('Generate Themes', $actions["temp"])
            //->addItem('Cleanup Wallpaper Folders', $callNew, true)
            //->setItemExtra('[13]')
            //->addCheckboxItem('Shuffle theme colors?', $importBase16)
            ->addLineBreak(' ')
            ->addLineBreak('⎺')
            ->setWidth($this->width);

        //$this->buildSubmenu($menuBuilder, $callNew, $importBase16);

        return $menuBuilder;
    }

    public function buildSubmenu(CliMenuBuilder $menuBuilder, $callNew, $importBase16)
    {
        $menuBuilder->addSubMenu('Base16 Commands', function (CliMenuBuilder $h) use ($callNew, $importBase16) {
            $h->setTitle('Base16 Palette Commands')
                ->setTitleSeparator('■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■▶ ● ◀■■■■■■■■■■■■■')
                ->setPadding(2, 4)
                ->setMarginAuto()
                ->setForegroundColour($this->fgColor)
                ->setBackgroundColour($this->bgColor)
                ->addLineBreak(' ')
                ->addStaticItem('TEST')
                ->addItem('Generate Spectrum Images', $callNew)
                ->addLineBreak(' ')
                ->addItem('Download & Import All Base16 Themes', $importBase16)
                ->addLineBreak(' ')
                ->addLineBreak('⎺')
                ->setWidth($this->width);
        });

        return $menuBuilder;
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule): void
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
