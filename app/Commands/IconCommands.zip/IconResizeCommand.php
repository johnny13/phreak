<?php

namespace App\Commands;

use Log;
use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;
use App\Commands\Phreaks\IconPhreaks;

class IconResizeCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon:resize

                            {--P|path : target folder}
                            {--N|new= : output to new folder, dont replace (optional)}
                            {--size= : custom size (optional)}';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'Batch resize SVG/PNG icons';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $icon = resource_path('icons/phreak-icon.png');

        $path   = $this->option('path');
        $newDir = $this->option('new');

        $this->info(" ");
        //$this->info(" Using file: " . $path . " ");

        IconPhreaks::resize_icons($path, $newDir);

        // Log::info('Icon Here: ' . $icon);

        $this->notify("Phreak Icons", "resizing completed!", $icon);
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule)
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
