<?php

namespace App\Commands;

use Log;
use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;
use App\Commands\Phreaks\IconPhreaks;

//use NunoMaduro\Dig;

class IconRecolorCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon:temp

                            {path : icon folder}
                            {--I|info : Display detailed coloring help message}
                            {--new= : Folder to store newly created new icons instead of replacing (optional)}
                            {--color= : Color all SVGs this color (optional)}
                            {--palette= : Color all SVGs using palette file (optional)}';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'Recolor multiple SVG icons with a color or a palette file.';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        // New Collection
        $collectionTemplate = resource_path('icons/collections.zip');

        // TODO: get collection name
        $newName = "icons_" . rand(1, 1000);

        // Unzip Archive
        

        // Foreach Folder, create entry in Database

        exit;
        //  dig()->caller();

        $this->newline();

        // $this->task(" Coloring Icons", function () {

        //     return true;
        // });

        $color = $this->color_logic();

        $path = $this->argument('path');

        $this->newline();

        $newDir = false;
        if ($this->option("new")) {
            $newDir = $this->option("new");
        }

        if (is_array($color)) {
            // Palette recolor
            IconPhreaks::batch_recolor_palette($path, $color, $newDir);
        } else {
            // Monocolor recolor
            IconPhreaks::batch_recolor_mono($path, $color, $newDir);
        }

        $icon = resource_path('icons/phreak-bride.svg');
        $this->notify("Recolor Command", "[DONE] Icon color change complete!", $icon);
    }

    /**
     * color_logic
     * confirms that either a single color, or palette file is set, but not both.
     *
     * @return mixed color string or array of colors
     */
    public function color_logic()
    {

        $color = false;

        // Handles all the various ways this command can be ran.
        if ($this->option('info')) {
            $helpString0 = "  1. When using the 'color' param monocolor icons are generated.";
            $helpString1 = "  2. The 'palette' command requires a JSON file and replaces every 'red' color with the 'red' palette color and so on.";
            $helpString2 = "      The format of the 'palette' file looks like this:";
            $helpString3 = "      {red: '#CC6666', yellow: '#FFFF66' ... }";
            $helpString4 = "      ROYGBIV + BW color codes are accepted.";
            $helpString5 = "      If a color isnt found in the file it won't be changed.";
            $this->newline();
            $this->info("  ==== ICON COLOR INFORMATION ====");
            $this->newline();
            $this->comment($helpString0);
            $this->newline();
            $this->comment($helpString1);
            $this->newline();
            $this->comment($helpString2);
            $this->comment($helpString3);
            $this->comment($helpString4);
            $this->comment($helpString5);
            $this->newline();
            return false;
        }

        if (!$this->option('color') && !$this->option('palette')) {
            $this->error("At least one color option must be set");
            exit;
        }

        if ($this->option('color') && $this->option('palette')) {
            $this->error("Both color option cannot be set");
            exit;
        }

        if ($this->option('palette')) {
            $colorFile = $this->option('palette');
            // Parse the Palette file into a nice array of colors.
            // Then Return the array.
            $color = array("test");
        } else if ($this->option('color')) {
            $color = $this->option('color');
        }

        if (!$color) {
            $this->error("Color option Error. Cannot continue.");
            exit;
        } else {
            return $color;
        }
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule)
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
