<?php

namespace App\Commands;

use Log;
use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;
use App\Commands\Phreaks\IconPhreaks;

class IconRenameCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon:rename

                            {--P|path : target folder}
                            {--N|new= : output to new folder, dont replace (optional)}
                            {--type= : rename method [slug, unique, hash] (optional)}';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'Batch sanitize & slugify icon filenames';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $icon = resource_path('icons/phreak-bride.svg');
        $this->info(" ");

        $path = $this->argument('path');

        //$phreaks = FilePhreaks::batch_rename_files($path);
        IconPhreaks::parse_json_list($path);
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule)
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
