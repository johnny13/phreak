<?php

namespace App\Commands;

use Log;
use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;
use App\Commands\Phreaks\IconPhreaks;

class IconReformatCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon:reformat

                            {path : EPS icon folder}
                            {new : SVG icon folder}';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'Reformat multiple EPS Icons to SVG';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $icon = resource_path('icons/phreak-bride.svg');
        $this->info(" ");

        $this->task(" Reformatting Icons", function () {
            $this->info(" ");

            $path = $this->argument('path');
            $newd = $this->argument('new');

            $this->info(" ");
            $this->info(" Target Directory: " . $path . " ");
            $this->info(" Moving SVGs to: " . $newd . " ");
            $this->info(" ");

            //$phreaks = FilePhreaks::batch_rename_files($path);
            IconPhreaks::convert_to_svg($path, $newd);

            return true;
        });

        // Log::info('Icon Here: ' . $icon);

        // $this->notify("Icon Command Status", "Ready to rock and roll", resource_path('icons/phreak-bride.svg'));

        // $option = $this->menu('Pizza menu', [
        //     'Freshly baked muffins',
        //     'Freshly baked croissants',
        //     'Turnovers, crumb cake, cinnamon buns, scones',
        // ])->open();
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule)
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
