<?php

namespace App\Commands;

use Log;
use Illuminate\Console\Scheduling\Schedule;
use LaravelZero\Framework\Commands\Command;
use App\Commands\Phreaks\IconPhreaks;

class IconStylesheetCommand extends Command
{
    /**
     * The signature of the command.
     *
     * @var string
     */
    protected $signature = 'icon:style

                            {path : icon folder}';

    /**
     * The description of the command.
     *
     * @var string
     */
    protected $description = 'Transform SVG Icons to SCSS/CSS classes';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $icon = resource_path('icons/phreak-bride.svg');
        $this->newline();

        $this->task(" Converting SVG Icons to SCSS Files", function () {
            $this->newline();

            $path = $this->argument('path');
            $this->info(" Using files in folder: " . $path . " ");

            $this->newline();
            $this->info(" @TODO STYLESHEET COMMAND INCOMPLETE.");
            $this->info(" NEED TO ADD IN FUNCTIONALITY TO RUN PHPICONIZR ON SVGs! ");
            $this->newline();


            //$phreaks = FilePhreaks::batch_rename_files($path);
            //IconPhreaks::parse_json_list($path);

            return true;
        });

        // Log::info('Icon Here: ' . $icon);

        // $this->notify("Icon Command Status", "Ready to rock and roll", resource_path('icons/phreak-bride.svg'));

        // $option = $this->menu('Pizza menu', [
        //     'Freshly baked muffins',
        //     'Freshly baked croissants',
        //     'Turnovers, crumb cake, cinnamon buns, scones',
        // ])->open();
    }

    /**
     * Define the command's schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    public function schedule(Schedule $schedule)
    {
        // $schedule->command(static::class)->everyMinute();
    }
}
