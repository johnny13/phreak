<?php

/**
 * Actions [Wallpaper] | Functions common across all, or to setup, wallpapers
 * Date: July 16 2021
 */

namespace App\Commands\Wallpaper;

use App\Commands\Phreaks\TUI;
use App\Commands\Phreaks\ColorPhreaks;
use App\Commands\Phreaks\FilePhreaks;
use App\Commands\Phreaks\PalettePhreaks;
use App\Commands\Phreaks\SixteenPhreaks;
use App\Commands\Phreaks\WallpaperPhreaks;

use App\Commands\Wallpaper\Raster;

// use Symfony\Component\Console\Helper\TableSeparator;
use Dallgoot\YAML;
use claviska\SimpleImage;

class Actions
{
    const PALETTEFILEDIR   = 'resources/palettes/base16/';

    public static function rasterGrungeGen()
    {
        $GenWall = new Raster();
        $image = new SimpleImage();
        $result = $GenWall->makeGrunge($image);
        return $result;
    }

    public static function newWallpaper($themeType, $themeName, $shuffle)
    {
        $results = array();

        // Get the colors
        if ($themeType === "palette")
            $allColors = WallpaperPhreaks::setupColors($themeType, $shuffle, $themeName);
        else
            $allColors = SixteenPhreaks::spectrumSorter($themeName, $shuffle);

        $results["colors"]    = $allColors["colors"];
        $results["bg"]        = $allColors["background"];
        $results["tc"]        = count($allColors["colors"]);
        $results["themeName"] = $allColors["theme"];
        $results["themeType"] = $themeType;
        $results["shuffle"]   = $shuffle;

        if(isset($allColors["grays"]))
            $results["grays"] = $allColors["grays"];

        return $results;
    }

    
}
